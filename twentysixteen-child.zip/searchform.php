<form action="<?php the_permalink(); ?>" role="search" method="get">
	<input value="" type="search" name="s" placeholder="Search..." class="search-form-data">
	<button type="submit" class="search-form-btn">
							Search
	</button> 
</form>