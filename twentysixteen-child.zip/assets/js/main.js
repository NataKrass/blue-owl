$(document).ready(function(){
	// main slider
  $("#slider").owlCarousel({
    stagePadding: 0,
    loop:true,
    margin:0,
    singleItem:true,
    navigation : true,
    dots:true,
    autoplay: true,
    autoplaySpeed: 1000,
    pagination: true,
    paginationNumbers: true,
    responsive:{
        0:{
            items:1,
        },
        600:{
            items:1,
            stagePadding: 0
        },
        1000:{
            items:1,
            stagePadding: 0
        },
        1200:{
            items:1,
            stagePadding: 0
        },
        1400:{
            items:1,
            stagePadding: 0
        },
        1600:{
            items:1,
            stagePadding: 0
        },
        1800:{
            items:1,
            stagePadding: 0
        }
    }
 });
  // news slider
   $("#news-carousel").owlCarousel({
   	stagePadding: 10,
    loop:true,
    margin:0,
    singleItem:true,
    navigation : true,
    dots:false,
    pagination: false,
    autoplay: true,
    autoplaySpeed: 2000,
    responsive:{
        0:{
            items:1,
        },
        600:{
            items:3,
            stagePadding: 0
        },
        1000:{
            items:4,
            stagePadding: 0
        },
        1200:{
            items:4,
            stagePadding: 0
        }
    }
   });
   // menu 
   $('.head-humburger').click(function () {
	   $('.menu-collaps').toggleClass('d-none');
    $('.menu-collaps').on('click', function() {
     });
    });

   $('.menu-item-has-children').hover(
       function(){ $(this).addClass('hover') },
       function(){ $(this).removeClass('hover') }
    )
   $('.sub-menu').hover(
       function(){ $(this).addClass('active_menu') },
       function(){ $(this).removeClass('active_menu') }
    )
   $('script').removeAttr("type");
   $('style').removeAttr("type");
});